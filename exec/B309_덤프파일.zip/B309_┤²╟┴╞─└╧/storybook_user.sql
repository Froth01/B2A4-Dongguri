-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: storybook
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `daily_limit_count` int NOT NULL,
  `created_date` datetime(6) DEFAULT NULL,
  `last_modify_date` datetime(6) DEFAULT NULL,
  `user_id` bigint NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `profile_image_url` varchar(255) DEFAULT NULL,
  `oauth_server_type` enum('KAKAO') DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (5,'2024-08-16 01:11:42.187778','2024-08-16 01:34:47.871607',1,'rsp916@hanmail.net','박선민','선민입니다','https://b2a4.s3.ap-northeast-2.amazonaws.com/881c2134-3f2f-4d5c-8550-1708b889fc71.jpg','KAKAO'),(2,'2024-08-16 01:19:25.866831','2024-08-16 02:03:34.443923',2,'pyb0718@naver.com','ㅂㅇㅂ','보라','https://b2a4.s3.ap-northeast-2.amazonaws.com/44376454-5c57-4344-80ac-71cce99a9779.jpg','KAKAO'),(5,'2024-08-16 01:39:55.672631','2024-08-16 01:55:05.107515',3,'bubbleutopia@hanmail.net','정영일','동현왕자','https://b2a4.s3.ap-northeast-2.amazonaws.com/b9ab9935-b511-4df9-985a-8ca86436c88b.jpg','KAKAO'),(2,'2024-08-16 01:41:16.163667','2024-08-16 02:18:53.574531',4,'022686@naver.com','이건희','거니','https://b2a4.s3.ap-northeast-2.amazonaws.com/f096d174-5309-41cb-a865-651dd442a952.jpg','KAKAO'),(3,'2024-08-16 05:47:05.245146','2024-08-16 08:41:33.532506',5,'ongyeom14@naver.com','동민','동민','https://b2a4.s3.ap-northeast-2.amazonaws.com/685d5b6b-76a3-4c06-9e77-5c46ca91f07e.jpg','KAKAO');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  8:47:19
