-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: storybook
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `comment_id` bigint NOT NULL AUTO_INCREMENT,
  `created_date` datetime(6) DEFAULT NULL,
  `last_modify_date` datetime(6) DEFAULT NULL,
  `storybook_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`comment_id`),
  KEY `FKilopprq4u110bc8mf7eou6d7m` (`storybook_id`),
  KEY `FK8kcum44fvpupyw6f5baccx25c` (`user_id`),
  CONSTRAINT `FK8kcum44fvpupyw6f5baccx25c` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `FKilopprq4u110bc8mf7eou6d7m` FOREIGN KEY (`storybook_id`) REFERENCES `storybook` (`storybook_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (1,'2024-08-16 01:55:39.987325','2024-08-16 01:55:39.987325',3,3,'아쉬워요!! ㅠㅠㅠㅠ'),(2,'2024-08-16 01:55:50.088551','2024-08-16 01:55:50.088551',6,3,'시원한 바다!!'),(3,'2024-08-16 01:56:09.836367','2024-08-16 01:56:09.836367',9,3,'멋있어요~~'),(4,'2024-08-16 01:56:27.255183','2024-08-16 01:56:27.255183',7,3,'블록놀이 재밌어요~~'),(5,'2024-08-16 01:57:06.158473','2024-08-16 01:57:06.158473',13,1,'저도 나무 친구들과 놀고싶어요!'),(6,'2024-08-16 01:59:23.535552','2024-08-16 01:59:23.535552',9,1,'멋있는 이야기네요!!'),(7,'2024-08-16 02:03:36.382967','2024-08-16 02:03:36.382967',14,1,'재밌는 동화네요!! 그림도 멋있어요'),(8,'2024-08-16 05:50:27.075977','2024-08-16 05:50:27.075977',14,5,'그림 너무 귀여워요 ㅎㅎ'),(9,'2024-08-16 05:50:57.893086','2024-08-16 05:50:57.893086',12,5,'이야기가 너무 감동적이에요!'),(10,'2024-08-16 05:51:31.584861','2024-08-16 05:51:31.584861',13,5,'루키 재미있었겠다!!'),(11,'2024-08-16 05:51:48.807910','2024-08-16 05:51:48.807910',16,5,'저도 피크닉을 떠나고 싶어졌어요!'),(12,'2024-08-16 05:52:05.753274','2024-08-16 05:52:05.753274',19,5,'내일 친구랑 딱지 치기 해야지~'),(13,'2024-08-16 05:52:41.297080','2024-08-16 05:52:41.297080',23,5,'산꼭대기에서 파란하늘 보는 거 진짜 멋져요!'),(14,'2024-08-16 05:53:18.216598','2024-08-16 05:53:18.216598',11,5,'말 잘 들을게요....'),(15,'2024-08-16 08:44:20.238251','2024-08-16 08:44:20.238251',21,5,'기린한테 소중한 추억으로 남겠네요');
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  8:47:21
