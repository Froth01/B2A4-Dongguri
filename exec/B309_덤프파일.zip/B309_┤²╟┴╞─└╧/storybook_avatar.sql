-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: storybook
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `avatar`
--

DROP TABLE IF EXISTS `avatar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avatar` (
  `exp` int NOT NULL,
  `is_representative` bit(1) NOT NULL,
  `avatar_id` bigint NOT NULL AUTO_INCREMENT,
  `created_date` datetime(6) DEFAULT NULL,
  `last_modify_date` datetime(6) DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `avatar_level` enum('ONE','THREE','TWO') DEFAULT NULL,
  `avatar_type` enum('BINI','GEONI','GYEOMI','ILI','MINI') DEFAULT NULL,
  `display_level` enum('ONE','THREE','TWO') DEFAULT NULL,
  PRIMARY KEY (`avatar_id`),
  KEY `FK424996avyt89fp16dknjxyda` (`user_id`),
  CONSTRAINT `FK424996avyt89fp16dknjxyda` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avatar`
--

LOCK TABLES `avatar` WRITE;
/*!40000 ALTER TABLE `avatar` DISABLE KEYS */;
INSERT INTO `avatar` VALUES (5,_binary '\0',1,'2024-08-16 01:11:42.189781','2024-08-16 01:36:57.468752',1,'겨미','TWO','GYEOMI','TWO'),(0,_binary '\0',2,'2024-08-16 01:11:42.191175','2024-08-16 01:11:42.191175',1,'거니','ONE','GEONI','ONE'),(0,_binary '\0',3,'2024-08-16 01:11:42.192791','2024-08-16 01:11:42.192791',1,'일이','ONE','ILI','ONE'),(0,_binary '\0',4,'2024-08-16 01:11:42.195111','2024-08-16 01:11:42.195111',1,'비니','ONE','BINI','ONE'),(0,_binary '',5,'2024-08-16 01:11:42.196263','2024-08-16 01:36:57.468614',1,'미니','ONE','MINI','ONE'),(2,_binary '',6,'2024-08-16 01:19:25.868157','2024-08-16 02:03:59.530218',2,'겨미','ONE','GYEOMI','ONE'),(0,_binary '\0',7,'2024-08-16 01:19:25.869879','2024-08-16 01:19:25.869879',2,'거니','ONE','GEONI','ONE'),(0,_binary '\0',8,'2024-08-16 01:19:25.870730','2024-08-16 01:19:25.870730',2,'일이','ONE','ILI','ONE'),(0,_binary '\0',9,'2024-08-16 01:19:25.871536','2024-08-16 01:19:25.871536',2,'비니','ONE','BINI','ONE'),(0,_binary '\0',10,'2024-08-16 01:19:25.873420','2024-08-16 01:19:25.873420',2,'미니','ONE','MINI','ONE'),(0,_binary '\0',11,'2024-08-16 01:39:55.676187','2024-08-16 01:40:14.425574',3,'겨미','ONE','GYEOMI','ONE'),(0,_binary '\0',12,'2024-08-16 01:39:55.677699','2024-08-16 01:39:55.677699',3,'거니','ONE','GEONI','ONE'),(0,_binary '\0',13,'2024-08-16 01:39:55.679187','2024-08-16 01:39:55.679187',3,'일이','ONE','ILI','ONE'),(0,_binary '\0',14,'2024-08-16 01:39:55.680626','2024-08-16 01:39:55.680626',3,'비니','ONE','BINI','ONE'),(5,_binary '',15,'2024-08-16 01:39:55.682789','2024-08-16 01:55:29.147826',3,'미니','TWO','MINI','TWO'),(7,_binary '',16,'2024-08-16 01:41:16.165224','2024-08-16 02:19:16.356180',4,'겨미','TWO','GYEOMI','TWO'),(0,_binary '\0',17,'2024-08-16 01:41:16.167851','2024-08-16 01:41:16.167851',4,'거니','ONE','GEONI','ONE'),(0,_binary '\0',18,'2024-08-16 01:41:16.171318','2024-08-16 01:41:16.171318',4,'일이','ONE','ILI','ONE'),(0,_binary '\0',19,'2024-08-16 01:41:16.172710','2024-08-16 01:41:16.172710',4,'비니','ONE','BINI','ONE'),(0,_binary '\0',20,'2024-08-16 01:41:16.173616','2024-08-16 01:41:16.173616',4,'미니','ONE','MINI','ONE'),(3,_binary '',21,'2024-08-16 05:47:05.255358','2024-08-16 08:42:15.946220',5,'겨미','ONE','GYEOMI','ONE'),(0,_binary '\0',22,'2024-08-16 05:47:05.262518','2024-08-16 05:47:05.262518',5,'거니','ONE','GEONI','ONE'),(0,_binary '\0',23,'2024-08-16 05:47:05.265370','2024-08-16 05:47:05.265370',5,'일이','ONE','ILI','ONE'),(0,_binary '\0',24,'2024-08-16 05:47:05.266959','2024-08-16 05:47:05.266959',5,'비니','ONE','BINI','ONE'),(0,_binary '\0',25,'2024-08-16 05:47:05.268900','2024-08-16 05:47:05.268900',5,'미니','ONE','MINI','ONE');
/*!40000 ALTER TABLE `avatar` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  8:47:30
