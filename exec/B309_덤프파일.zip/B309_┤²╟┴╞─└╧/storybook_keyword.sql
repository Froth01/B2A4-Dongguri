-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: storybook
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `keyword`
--

DROP TABLE IF EXISTS `keyword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `keyword` (
  `keyword_id` bigint NOT NULL AUTO_INCREMENT,
  `storybook_id` bigint DEFAULT NULL,
  `keyword` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`keyword_id`),
  KEY `FK271w2a6muo4u7a8lrobmefyj1` (`storybook_id`),
  CONSTRAINT `FK271w2a6muo4u7a8lrobmefyj1` FOREIGN KEY (`storybook_id`) REFERENCES `storybook` (`storybook_id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `keyword`
--

LOCK TABLES `keyword` WRITE;
/*!40000 ALTER TABLE `keyword` DISABLE KEYS */;
INSERT INTO `keyword` VALUES (3,2,'하늘'),(4,2,'토끼'),(5,3,'주말'),(6,3,'딸기 케이크'),(7,3,'또 먹고싶다'),(8,4,'트램펄린'),(9,4,'언니'),(10,4,'엄청 높게 뛰기'),(11,4,'재밌었다'),(16,6,'주말'),(17,6,'바다'),(18,6,'가족'),(19,6,'파라솔'),(20,7,'동생'),(21,7,'블록'),(22,7,'성'),(23,8,'동물원'),(24,8,'공작새'),(25,8,'나들이'),(26,9,'엄마'),(27,9,'아빠'),(28,10,'우리집'),(29,10,'별똥별'),(30,10,'꽃밭'),(31,11,'사자'),(32,11,'밤'),(33,11,'말안듣는 어린이'),(34,12,'바닷속'),(35,12,'인어공주'),(36,12,'문어'),(37,12,'물고기'),(38,13,'숲속'),(39,13,'너구리'),(40,13,'나무'),(41,14,'하늘'),(42,14,'토끼'),(43,15,'바다'),(44,15,'물고기'),(45,15,'문어'),(46,16,'가족'),(47,16,'행복'),(50,18,'자매'),(51,18,'인어공주'),(52,19,'친구'),(53,19,'딱지 치기'),(56,21,'기린'),(57,21,'사과나무'),(58,22,'등산'),(59,22,'가족'),(60,23,'등산'),(61,23,'가족'),(62,23,'햇살'),(63,23,'산'),(64,24,'토끼'),(65,24,'달리기시합'),(66,24,'목걸이'),(70,26,'기사님'),(71,26,'모험'),(72,27,'공주님'),(73,27,'눈물'),(74,27,'손수건');
/*!40000 ALTER TABLE `keyword` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  8:47:06
