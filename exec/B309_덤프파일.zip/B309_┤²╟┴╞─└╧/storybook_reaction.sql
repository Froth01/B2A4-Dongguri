-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: storybook
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `reaction`
--

DROP TABLE IF EXISTS `reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reaction` (
  `created_date` datetime(6) DEFAULT NULL,
  `last_modify_date` datetime(6) DEFAULT NULL,
  `reaction_cnt_id` bigint DEFAULT NULL,
  `reaction_id` bigint NOT NULL AUTO_INCREMENT,
  `storybook_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `reaction_type` enum('FUN','HAPPY','JOY','SAD') DEFAULT NULL,
  PRIMARY KEY (`reaction_id`),
  KEY `FK77t86m71ww61g8aj4h0r4ttp9` (`reaction_cnt_id`),
  KEY `FK1kmeq338se06tcxvf4naf3kl6` (`storybook_id`),
  KEY `FKp68qgeq3telx6adl7hssrdxbw` (`user_id`),
  CONSTRAINT `FK1kmeq338se06tcxvf4naf3kl6` FOREIGN KEY (`storybook_id`) REFERENCES `storybook` (`storybook_id`),
  CONSTRAINT `FK77t86m71ww61g8aj4h0r4ttp9` FOREIGN KEY (`reaction_cnt_id`) REFERENCES `reaction_count` (`reaction_cnt_id`),
  CONSTRAINT `FKp68qgeq3telx6adl7hssrdxbw` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reaction`
--

LOCK TABLES `reaction` WRITE;
/*!40000 ALTER TABLE `reaction` DISABLE KEYS */;
INSERT INTO `reaction` VALUES ('2024-08-16 01:55:51.820605','2024-08-16 01:55:51.820605',6,1,6,3,'JOY'),('2024-08-16 01:55:56.655420','2024-08-16 01:55:56.655420',3,2,3,3,'SAD'),('2024-08-16 01:56:01.404800','2024-08-16 01:56:01.404800',9,3,9,3,'HAPPY'),('2024-08-16 01:56:17.949255','2024-08-16 01:56:17.949255',7,4,7,3,'JOY'),('2024-08-16 01:56:55.290573','2024-08-16 01:56:55.290573',13,5,13,1,'FUN'),('2024-08-16 01:57:11.331171','2024-08-16 01:57:11.331171',13,6,13,1,'HAPPY'),('2024-08-16 01:57:58.133165','2024-08-16 01:57:58.133165',12,7,12,2,'HAPPY'),('2024-08-16 02:02:27.427140','2024-08-16 02:02:27.427140',12,8,12,1,'JOY'),('2024-08-16 02:03:20.828965','2024-08-16 02:03:20.828965',14,9,14,1,'HAPPY'),('2024-08-16 02:04:05.472798','2024-08-16 02:04:05.472798',21,10,21,2,'SAD');
/*!40000 ALTER TABLE `reaction` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  8:47:11
