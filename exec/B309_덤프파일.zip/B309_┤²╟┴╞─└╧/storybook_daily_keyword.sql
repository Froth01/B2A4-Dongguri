-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: storybook
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `daily_keyword`
--

DROP TABLE IF EXISTS `daily_keyword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_keyword` (
  `created_date` datetime(6) DEFAULT NULL,
  `daily_keyword_id` bigint NOT NULL AUTO_INCREMENT,
  `last_modify_date` datetime(6) DEFAULT NULL,
  `character_keyword` enum('CAT','DOG','DRAGON','FAIRY','FAMILY','HARE','KNIGHT','MERMAID','PRINCE','PRINCESS','ROBOT','SORCERESS','WIZARD') DEFAULT NULL,
  `genre_keyword` enum('FUN','HAPPY','JOY','SAD') DEFAULT NULL,
  `place_keyword` enum('BEACH','CAVE','CLOUDS','DESERT','FARM','FOREST','GARDEN','HILL','HOUSE','ISLAND','LAKE','MOUNTAIN','PARK','RAINBOW_SPOT','RIVER','SANDY_BEACH','SEA','SKY','SNOW_COVERED_MOUNTAIN','TOWN','VALLEY','WATERFALL','WINDY_FIELD') DEFAULT NULL,
  PRIMARY KEY (`daily_keyword_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_keyword`
--

LOCK TABLES `daily_keyword` WRITE;
/*!40000 ALTER TABLE `daily_keyword` DISABLE KEYS */;
INSERT INTO `daily_keyword` VALUES ('2024-08-16 01:08:56.453101',1,'2024-08-16 01:08:56.453101','HARE','FUN','SKY');
/*!40000 ALTER TABLE `daily_keyword` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  8:46:58
